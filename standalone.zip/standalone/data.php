<?php
$key=base64_encode('49cf8d7041ffdadca1b80ba1a2957c93:730278225fa1a93e4156012c5c73a56c'); //apipass:apikey
$folder='standalone'; //a root folder
$temp='tmp';  //temp upload folder, mostly servers "tmp"
?>